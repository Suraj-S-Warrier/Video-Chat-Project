const asyncHandler = require("express-async-handler");
const User = require("../models/userModel.js");
const generateToken = require("../config/generateToken.js");

const registerUser = asyncHandler(async (req, res) => {
  const { name, email, password, pic } = req.body;

  if (!name || !email || !password) {
    res.status(400);
    throw new Error("Please enter all fields");
  }

  const userExists = await User.findOne({ email });
  if (userExists) {
    res.status(400);
    throw new Error("User already exists");
  }

  const user = await User.create({
    name,
    email,
    password,
    pic,
  });

  if (user) {
    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      pic: user.pic,
      token: generateToken(user._id),
    });
  } else {
    res.status(400);
    throw new Error("Failed to Create the User");
  }
});

const authUser = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });
  if (user && (await user.matchPassword(password))) {
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      pic: user.pic,
      token: generateToken(user._id),
    });
  } else {
    res.status(401);
    throw new Error("Invalid Email or Password");
  }
});

//api/user?search=suraj
const allUsers = asyncHandler(async (req, res) => {
  const keyword = req.query.search
    ? {
        $or: [
          { name: { $regex: req.query.search, $options: "i" } },
          { email: { $regex: req.query.search, $options: "i" } },
        ],
      }
    : {};

  const users = await User.find(keyword).find({ _id: { $ne: req.user._id } });
  console.log(users);
  res.send(users);
});

const getLastSeen = asyncHandler(async (req, res) => {
  const { userId } = req.query;
  const user = await User.findById(userId, "lastSeen");
  if (user) {
    console.log(`got the info from mongo: ${user}`);
    res.json(user);
  } else {
    res.status(401);
    throw new Error("No last Seen");
  }
});

const UpdateLastSeen = asyncHandler(async (req, res) => {
  // const { userId } = req.body;
  const user = await User.findByIdAndUpdate(req.user._id, {
    lastSeen: Date.now(),
  });

  console.log(`user ${user} has logged out in mongo`);
  if (user) {
    res.status(200).send(user);
  } else {
    res.status(401);
    throw new Error("Couldnt update");
  }
});

// @desc    Update user password
// @route   PUT /api/user/update-password
// @access  Private
const updatePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;

  const user = await User.findById(req.user._id);

  if (!user) {
    res.status(404);
    throw new Error("User not found");
  }

  // Check if the old password matches
  if (!(await user.matchPassword(currentPassword))) {
    res.status(401);
    throw new Error("Old password is incorrect");
  } else {
    user.password = newPassword;
    await user.save();

    res.status(200).json({ message: "Password updated successfully" });
  }

  // Update the password
});

// Update user's name
const updateUserName = asyncHandler(async (req, res) => {
  const { editedName } = req.body;

  // Check if the new name is provided
  if (!editedName) {
    res.status(400);
    throw new Error("New name is required");
  }

  try {
    // Find the user by ID
    const user = await User.findById(req.user._id);

    // Check if the user exists
    if (!user) {
      res.status(404);
      throw new Error("User not found");
    }

    // Update the user's name
    user.name = editedName;

    // Save the updated user
    await user.save();

    // Respond with the updated user
    res.status(200).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      pic: user.pic,
      lastSeen: user.lastSeen,
    });
  } catch (error) {
    res.status(500);
    throw new Error("Failed to update user's name");
  }
});

const updateUserPic = asyncHandler(async (req, res) => {
  const { selectedImage } = req.body;

  // Check if the new name is provided
  if (!selectedImage) {
    res.status(400);
    throw new Error("New name is required");
  }

  try {
    // Find the user by ID
    const user = await User.findById(req.user._id);

    // Check if the user exists
    if (!user) {
      res.status(404);
      throw new Error("User not found");
    }

    // Update the user's pic
    user.pic = selectedImage;

    // Save the updated user
    await user.save();

    // Respond with the updated user
    res.status(200).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      pic: user.pic,
      lastSeen: user.lastSeen,
    });
  } catch (error) {
    res.status(500);
    throw new Error("Failed to update user's pic");
  }
});

const getUserInfo = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  if (!user) {
    res.status(404);
    throw new Error("User not found");
  } else {
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      pic: user.pic,
      token: generateToken(user._id),
    });
  }
});

const getOtherUserInfo = asyncHandler(async (req, res) => {
  const { uid } = req.query;
  console.log(uid);
  const user = await User.findById(uid);
  if (!user) {
    res.status(404);
    throw new Error("User not found");
  } else {
    res.json({
      name: user.name,
    });
  }
});

module.exports = {
  registerUser,
  authUser,
  allUsers,
  getLastSeen,
  UpdateLastSeen,
  updatePassword,
  updateUserName,
  getUserInfo,
  updateUserPic,
  getOtherUserInfo,
};
