const mongoose = require("mongoose");
const messageModel  =mongoose.Schema(
    {
        sender:{
            type:mongoose.Schema.Types.ObjectId,
            ref:"User",
        },
        content:{
            type: String,
            trim: true,
        },
        chat:{
            type:mongoose.Schema.Types.ObjectId,
            ref:"Chat",
        },
        url:{
            type:String,
            default:"",
        },
        isDis:{
            type:Boolean,
            default:"false",
        },
        disTime:{
            type:Date,
            default:Date.now(),
        },
    },
    {
        timestamps: true,
    }
);

const Message = mongoose.model("Message",messageModel);
module.exports = Message;