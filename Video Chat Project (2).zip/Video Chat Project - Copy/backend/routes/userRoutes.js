const express = require("express");
const { registerUser, authUser, allUsers, getLastSeen, UpdateLastSeen, updatePassword, updateUserName, getUserInfo, updateUserPic, getOtherUserInfo } = require("../controllers/userControllers");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();

router.route("/").post(registerUser).get(protect,allUsers);
router.post("/login", authUser);
router.route("/lastseen").get(protect,getLastSeen).put(protect,UpdateLastSeen);
router.route("/updatepassword").put(protect,updatePassword);
router.route("/updateusername").put(protect,updateUserName);
router.route("/userinfo").get(protect,getUserInfo);
router.route("/userpic").put(protect,updateUserPic);
router.route("/getname").get(protect,getOtherUserInfo);

module.exports = router;
