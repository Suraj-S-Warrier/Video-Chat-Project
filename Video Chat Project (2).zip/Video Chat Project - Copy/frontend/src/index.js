import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import { ChakraProvider } from "@chakra-ui/react";
import { BrowserRouter } from "react-router-dom";
import ChatProvider from "./Context/ChatProvider.js";
// import AgoraRTC from "agora-rtc-sdk-ng";
// import { AgoraRTCProvider } from "agora-rtc-react";


const root = ReactDOM.createRoot(document.getElementById("root"));

// const client = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });
root.render(
  <BrowserRouter>
    {/* <AgoraRTCProvider client={client}> */}
      <ChatProvider>
        <ChakraProvider>
          <App />
        </ChakraProvider>
      </ChatProvider>
    {/* </AgoraRTCProvider> */}
  </BrowserRouter>
);
