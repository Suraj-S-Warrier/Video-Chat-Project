import React from 'react'

import AgoraRTC from "agora-rtc-sdk-ng";
import { AgoraRTCProvider } from "agora-rtc-react";
import Basics from './VideoPageReadyMade';
const client = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });
const dummyFile = () => {

  return(
    <AgoraRTCProvider client={client}>
        <Basics/>
  </AgoraRTCProvider>
  ) 
}

export default dummyFile
