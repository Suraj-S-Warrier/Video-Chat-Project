import React, { useEffect, useState, useRef } from "react";
import ReactDOM from "react-dom";
import "./VideoPage.css";
import { options, rtc } from "./videoConstants";
import AgoraRTC from "agora-rtc-sdk-ng";
import { useHistory } from "react-router-dom";
import { Box, Button, Flex, Switch } from "@chakra-ui/react";

const VideoPage = () => {
  const [joined, setJoined] = useState(0);
  const channelRef = useRef("");
  const history = useHistory();
  const [videoButtonEnabled,setVideoButtonEnabled] = useState(true);
  const [audioButtonEnabled, setAudioButtonEnabled] = useState(true);


  async function handleSubmit() {
    try {

      setJoined(true);

      rtc.client = AgoraRTC.createClient({ mode: "rtc", codec: "h264" });
      const uid = await rtc.client.join(
        options.appId,
        "main",
        options.token,
        null
      );

      rtc.localAudioTrack = await AgoraRTC.createMicrophoneAudioTrack();
      rtc.localVideoTrack = await AgoraRTC.createCameraVideoTrack();
      console.log(`UID is ${rtc.client.uid}`);

      rtc.localVideoTrack.play("local-stream");

      rtc.client.on("user-published", async (user, mediaType) => {
        await rtc.client.subscribe(user, mediaType);
        setJoined(1);
        console.log("subscribe success");

        if (mediaType === "video" || mediaType === "all") {
          const remoteVideoTrack = user.videoTrack;
          // const PlayerContainer = React.createElement("div", {
          //   id: user.uid,
          //   className: "stream",
          // });

          // ReactDOM.render(
          //   PlayerContainer,
          //   document.getElementById("remote-stream"),
          //   () => {
          //     user.videoTrack.play(`${user.uid}`);
          //   }
          // );
          user.videoTrack.play("remote-stream")
        }

        if (mediaType === "audio" || mediaType === "all") {
          const remoteAudioTrack = user.audioTrack;
          remoteAudioTrack.play();
        }
      });

      rtc.client.on("user-unpublished", (user) => {
        // const playerContainer = document.getElementById(user.uid);
        // playerContainer && playerContainer.remove();
        // handleLeave();

      });

      await rtc.client.publish([rtc.localAudioTrack, rtc.localVideoTrack]);

      console.log("publish success!");
    } catch (error) {
      console.error(error);
    }
  }

  async function handleLeave() {
    try {
      const localContainer = document.getElementById("local-stream");

      rtc.localAudioTrack.close();
      rtc.localVideoTrack.close();

      setJoined(false);
      localContainer.textContent = "";

      // rtc.client.remoteUsers.forEach((user) => {
      //   const playerContainer = document.getElementById(user.uid);
      //   playerContainer && playerContainer.remove();
      // });

      await rtc.client.leave();
      history.push("/chats");
    } catch (err) {
      console.error(err);
    }
  }

  const handleVideoToggle = async() => {
    if (rtc.localVideoTrack) {
      const videoTrack = rtc.localVideoTrack;
      // videoTrack.setEnabled(!videoTrack.enabled);
      // videoTrack.enabled= false;
      //setVideoButtonEnabled(!videoButtonEnabled);
      if(videoTrack.enabled){
        await videoTrack.setEnabled(false);
        await rtc.client.unpublish(videoTrack);
      }
      else{
        await videoTrack.setEnabled(true);
        await rtc.client.publish(videoTrack);
      }
      // videoTrack.setEnabled(!videoTrack.enabled);
    }
  };

  const handleAudioToggle = () => {
    if (rtc.localAudioTrack) {
      const audioTrack = rtc.localAudioTrack;
      audioTrack.setEnabled(!audioTrack.disabled);

      //setAudioButtonEnabled(!audioButtonEnabled);
    }
  };

  useEffect(() => {

    handleSubmit();

    try {
      const initialUser = rtc.client.remoteUsers.find(
        (user) => user.uid !== rtc.client.uid
      ); // Replace initialUserId with the actual user ID of the initial user
      if (initialUser && initialUser.hasVideo) {
        console.log(`the other user is :${initialUser.uid}`);
        const initialUserVideoTrack = initialUser.videoTrack;
        // const InitialUserContainer = React.createElement("div", {
        //   id: initialUser.uid,
        //   className: "stream",
        // });

        // ReactDOM.render(
        //   InitialUserContainer,
        //   document.getElementById("remote-stream"),
        //   () => {
        //     initialUserVideoTrack.play(`${initialUser.uid}`);
        //   }
        // );
        initialUserVideoTrack.play("remote-stream")
      }
      
    } catch (error) {
      console.log(`Error: ${error}`);
    }
    
  }, []); // Run this effect only once during the component's mount

  return (
    <Box
      bg="white"
      p={4}
      borderRadius="md"
      boxShadow="md"
      width="80%"
      height="80%"
      maxH="700px"
      maxW="800px"
      mx="auto"
      mt={10}
      overflow="hidden" // Add this line to prevent overflow
    >
      <Flex direction="column" align="center" justify="center" h="100%">
        <Flex
          direction="row"
          justify="space-between"
          width="100%"
          flex="1" // Add this line to make the inner flex containers take equal portions
        >
          <div
            id="local-stream"
            className="stream local-stream"
            style={{ marginRight: "10px", width: "calc(50% - 5px)" }} // Adjusted width calculation
          ></div>
          <div
            id="remote-stream"
            className="stream remote-stream"
            style={{ width: "calc(50% - 5px)" }} // Adjusted width calculation
          ></div>
        </Flex>
        <Flex
          direction="row"
          align="center"
          justify="center"
          mt={4}
          spacing={4}
          width="100%"
        >
          <Button
            colorScheme="red"
            onClick={handleLeave}
            disabled={!joined}
            mr={4}
          >
            End Call
          </Button>
          <Button
            colorScheme="teal"
            size="lg"
            onClick={handleVideoToggle}
            mr={4}
          >
            Video
          </Button>
          <Button colorScheme="teal" size="lg" onClick={handleAudioToggle}>
            Audio
          </Button>
        </Flex>
      </Flex>
    </Box>
  );
};

export default VideoPage;
