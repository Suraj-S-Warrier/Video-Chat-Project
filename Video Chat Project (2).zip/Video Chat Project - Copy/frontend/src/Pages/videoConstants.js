export const rtc = {
  // For the local client
  client: null,
  // For the local audio and video tracks
  localAudioTrack: null,
  localVideoTrack: null,
};

export const options = {
  // Pass your app ID here
  appId: "0e765e1e2cc844af854fff29bb16f6f3",
  // Pass a token if your project enables the App Certificate
  token:
    "007eJxTYLj01EerWXNr6qqwIL+CrgYXd841j20m5C7ImfduXRlnSIsCg0GquZlpqmGqUXKyhYlJYpqFqUlaWpqRZVKSoVmaWZpx45/81IZARgbuK8uZGRkgEMRnYchNzMxjYAAAOpsfoQ==",
};
