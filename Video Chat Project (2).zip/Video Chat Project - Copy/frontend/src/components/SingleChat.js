import React, { useEffect, useReducer, useState } from "react";
import _debounce from "lodash/debounce";
import { ChatState } from "../Context/ChatProvider";
import {
  Box,
  Button,
  FormControl,
  Icon,
  IconButton,
  Input,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Spinner,
  Text,
  useDisclosure,
  useToast,
} from "@chakra-ui/react";
import {
  ArrowBackIcon,
  AttachmentIcon,
  CheckIcon,
  DownloadIcon,
  TimeIcon,
} from "@chakra-ui/icons";
import { getSender, getSenderFull } from "../config/ChatLogics";
import ProfileModal from "./miscellaneous/ProfileModal";
import UpdateGroupChatModal from "./miscellaneous/UpdateGroupChatModal";
import axios from "axios";
import "./styles.css";
import ScrollableChat from "./ScrollableChat";
import io from "socket.io-client";
import Lottie from "react-lottie";
import animationData from "../animations/typing.json";
import VideoCallButton from "./VideoCallButton";
import AudioCallButton from "./AudioCallButton";
// import AgoraRTC from "agora-rtc-sdk"; // Make sure to import Agora SDK
import { useHistory } from "react-router-dom";
import { AiOutlineMore } from "react-icons/ai";

const ENDPOINT = "http://localhost:5000";
var socket, selectedChatCompare;
const SingleChat = ({ fetchAgain, setFetchAgain }) => {
  // const [, forceUpdate] = useReducer((x) => x + 1, 0);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [newMessage, setNewMessage] = useState("");
  const [socketConnected, setSocketConnected] = useState(false);
  const [typing, setTyping] = useState(false);
  const [istyping, setIsTyping] = useState(false);
  const [isOnline, setIsOnline] = useState(false);
  const [receiverId, setReceiverId] = useState();
  const [receiverLastSeen, setReceiverLastSeen] = useState();
  const [videoCallInfo, setVideoCallInfo] = useState(null);
  const history = useHistory();
  const [caller, setCaller] = useState();
  const toast = useToast();
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [fileURL, setFileURL] = useState();
  const [disappear, setDisappear] = useState();

  const {
    user,
    selectedChat,
    setSelectedChat,
    notification,
    setNotification,
    setSocketState,
    light,
    lightColor,
    darkColor,
  } = ChatState();

  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  const fetchMessages = async () => {
    if (!selectedChat) return;

    try {
      const config = {
        headers: {
          Authorization: `Bearer ${user.token}`,
        },
      };

      setLoading(true);

      const { data } = await axios.get(
        `/api/message/${selectedChat._id}`,
        config
      );
      //console.log(data);
      setMessages(data);
      console.log(data);
      setLoading(false);

      socket.emit("join chat", selectedChat._id);
    } catch (error) {
      toast({
        title: "Error Occured!",
        description: "Failed to Load the Messages",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom",
      });
    }
  };

  const sendMessage = async (event) => {
    if (event.key == "Enter" && newMessage) {
      socket.emit("stop typing", selectedChat._id);
      try {
        var isDis;
        if(!disappear ||  disappear==0){
          isDis = false;
        }
        else{
          isDis = true;
        }
        var disTime;
        if(!isDis){
          disTime=Date.now();
        }
        else if(disappear==1){
          disTime = Date.now() + (1000 * 60);
        }
        else if(disappear==2){
          disTime= Date.now() + 1000 * 60 * 60 * 24;
        }
        const config = {
          headers: {
            "Content-type": "application/json",
            Authorization: `Bearer ${user.token}`,
          },
        };
        console.log(`the disappearing time is: ${disTime}`);
        setNewMessage("");
        const { data } = await axios.post(
          "/api/message",
          {
            content: newMessage,
            chatId: selectedChat._id,
            isDis: isDis,
            disTime: disTime,
          },
          config
        );
        console.log(data);
        socket.emit("new message", data);
        setMessages([...messages, data]);
      } catch (error) {
        toast({
          title: "Error Occured!",
          description: "Failed to send the Message",
          status: "error",
          duration: 5000,
          isClosable: true,
          position: "bottom",
        });
      }
    }
  };
  useEffect(() => {
    setIsOnline(false);
    setReceiverId(undefined);
    //console.log(selectedChat);
    if (!selectedChat?.isGroupChat) {
      const receiver = selectedChat?.users?.find((u) => u._id !== user._id);

      if (receiver) {
        console.log(`receiverId to be changed to ${receiver._id}`);
        console.log(`before changing reciever id:${receiverId}`);
        setReceiverId(receiver._id);

        // Call socket event after setting the receiver ID
      }
    } else {
      setReceiverId(undefined);
    }

    if (selectedChat && user) {
      getLastSeen(selectedChat?.users?.find((u) => u._id !== user._id)._id);
    }

    if (selectedChat) {
      if (selectedChat.disappear == "0") {
        setDisappear(0);
      } else if (selectedChat.disappear == "1") {
        setDisappear(1);
      } else if (selectedChat.disappear == "2") {
        setDisappear(2);
      }
    }
  }, [selectedChat, user]);

  useEffect(() => {
    if (receiverId) {
      socket.emit("is online", receiverId, user._id);
    }
    console.log(`after changing receiver id:${receiverId}`);
  }, [receiverId, socket, user]);

  useEffect(() => {
    // console.log(receiverId);
    // receiver = receiver[0];
    // console.log(receiver._id);
    // setReceiverId(receiverId);

    const receiver = selectedChat?.users?.find((u) => u._id !== user._id);

    socket = io(ENDPOINT);
    setSocketState(socket);
    socket.emit("setup", user);

    socket.on("connected", () => setSocketConnected(true));
    // socket.emit("is online", receiverId, user._id);

    socket.on("typing_s", (room) => {
      //console.log("kitti");
      if (room == selectedChat._id) {
        setIsTyping(true);
      }
    });
    socket.on("stop typing_s", (room) => {
      //console.log("kitti");
      if (room == selectedChat._id) {
        setIsTyping(false);
      }
    });
    socket.on("is online?", (uid) => {
      socket.emit("yes online", uid, user._id);
    });

    socket.on("Online!", (uid) => {
      // console.log("Received Online! message for uid:", uid);
      // console.log("Current receiverId:", receiverId);
      // if (receiverId && receiverId == uid) {
      setIsOnline(true);
      // forceUpdate();
      // }
    });

    socket.on("logged out", (uid) => {
      if (receiver?._id && receiver?._id == uid) {
        setIsOnline(false);
        console.log("chat receiver logged out");
      }
    });
    socket.on("logged in", (uid) => {
      if (receiver?._id && receiver?._id == uid) {
        setIsOnline(true);
        console.log("chat receiver has logged in");
      }
    });

    socket.on("video call invitation", (videoCallData) => {
      // Handle incoming video call invitation
      // You might want to show a modal or notification to the user
      setVideoCallInfo(videoCallData);
    });

    return () => {
      socket.disconnect();
    };
  }, [selectedChat, user]);

  useEffect(() => {
    // Check if there's an ongoing video call and initiate it
    if (videoCallInfo) {
      initiateVideoCall(videoCallInfo);
    }
  }, [videoCallInfo]);

  const initiateVideoCall = (videoCallData) => {
    // Use Agora SDK to start the video call
    // You need to implement Agora SDK logic here
    // Refer to Agora documentation for detailed instructions
  };

  useEffect(() => {
    const fetchMessagesSync = async () => {
      try {
        await fetchMessages();
      } catch (error) {
        console.error("Couldnt fetch messages: ", error);
      }
    };
    fetchMessagesSync();

    selectedChatCompare = selectedChat;
  }, [selectedChat]);

  useEffect(() => {
    socket.on("message received", (newMessageReceived) => {
      if (
        !selectedChatCompare ||
        selectedChatCompare._id !== newMessageReceived.chat._id
      ) {
        if (!notification.includes(newMessageReceived)) {
          setNotification([newMessageReceived, ...notification]);
          setFetchAgain(!fetchAgain);
        }
      } else {
        setMessages([...messages, newMessageReceived]);
      }
    });

    socket.on("video call receiving", async (uid) => {
      videoCallModal(uid);
    });
  });

  const videoCallModal = async (uid) => {
    try {
      const config = {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${user.token}`,
        },
      };

      const { data } = await axios.get(
        `/api/user/getname?uid=${uid}`,

        config
      );
      console.log(data);
      setCaller(data.name);
      onOpen();
    } catch (error) {
      toast({
        title: "Error Occured!",
        description: "Failed to get username",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom",
      });
    }
  };

  const typingHandler = (e) => {
    setNewMessage(e.target.value);

    //typing indicator logic?
    if (!socketConnected) return;

    if (!typing) {
      setTyping(true);
      socket.emit("typing", selectedChat._id);
    }
    debounceStopTyping();
    // let lastTypingTime = new Date().getTime();
    // var timerLength = 3000;
    // setTimeout(() => {
    //   var timeNow = new Date().getTime();
    //   var timeDiff = timeNow - lastTypingTime;
    //   if (timeDiff >= timerLength && typing) {
    //     socket.emit("stop typing", selectedChat._id);
    //     setTyping(false);
    //   }
    // }, timerLength);
  };

  const debounceStopTyping = _debounce(() => {
    socket.emit("stop typing", selectedChat._id);
    setTyping(false);
  }, 3000);

  const formatDateTime = (dateTimeString) => {
    const dateTime = new Date(dateTimeString);
    const currentDate = new Date();

    // Check if the date is today
    const isToday =
      dateTime.getDate() === currentDate.getDate() &&
      dateTime.getMonth() === currentDate.getMonth() &&
      dateTime.getFullYear() === currentDate.getFullYear();

    // Format the date
    let formattedDate;
    if (isToday) {
      // If the date is today, display "today" along with the time
      formattedDate =
        "Today " +
        dateTime.toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "numeric",
          hour12: true,
        });
    } else {
      // If not today, display the full date
      formattedDate = dateTime.toLocaleString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "numeric",
        minute: "numeric",
        hour12: true,
      });
    }

    return formattedDate;
  };

  const getLastSeen = async (userId) => {
    console.log(userId);
    try {
      const config = {
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${user.token}`,
        },
      };

      const { data } = await axios.get(
        `/api/user/lastseen?userId=${userId}`,
        config
      );
      console.log(formatDateTime(data.lastSeen));
      setReceiverLastSeen(formatDateTime(data.lastSeen));
      // const {lastSeen} = data.data;
      // console.log(lastSeen)
      // setReceiverLastSeen(lastSeen);
    } catch (error) {
      toast({
        title: "Error Occured!",
        description: "Failed to get the last Seen",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom",
      });
    }
  };

  const hiddenFileInput = React.useRef(null);

  const handleClick = () => {
    hiddenFileInput.current.click();
  };

  const updateFile = async (file) => {
    const data = new FormData();

    const fileNameWithoutExtension = file.name.replace(/\.[^/.]+$/, "");

    data.append("file", file);
    console.log(file.name);
    data.append("upload_preset", "video-chat-app");
    data.append("cloud_name", "dz7ln36yd");
    data.append("public_id", fileNameWithoutExtension);
    fetch("https://api.cloudinary.com/v1_1/dz7ln36yd/auto/upload", {
      method: "post",
      body: data,
    })
      .then((res) => res.json())
      .then(async (data) => {
        // console.log(data.url.toString());
        // setFileURL(data.url.toString());
        try {
          const transformations = "fl_attachment";

          // Parse the URL
          const url = new URL(data.url);
          const pathArray = url.pathname.split("/");

          // Insert transformations into the path
          pathArray.splice(4, 0, transformations); // Insert at index 4

          // Update the URL
          url.pathname = pathArray.join("/");

          // The modified URL with transformations
          const modifiedUrl = url.toString();
          console.log(modifiedUrl);

          // Now you can use modifiedUrl as needed
          setFileURL(modifiedUrl);
          const config = {
            headers: {
              "Content-type": "application/json",
              Authorization: `Bearer ${user.token}`,
            },
          };

          const { newdata } = await axios.post(
            `/api/message/sendfile`,
            {
              url: modifiedUrl,
              content: file.name,
              chatId: selectedChat._id,
            },
            config
          );
          console.log(newdata);
        } catch (error) {
          toast({
            title: "Error Occured!",
            description: "Failed to send the file",
            status: "error",
            duration: 5000,
            isClosable: true,
            position: "bottom",
          });
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const updateDisappearStatus= async(status)=>{
    try {
      const config = {
        headers: {
          Authorization: `Bearer ${user.token}`,
        },
      };

      const { val } = await axios.put(`/api/chat/toggledismsg`, {chatId:selectedChat._id,disappear:status}, config);
      console.log(val);
      toast({
        title: "Disappearing messages set successfully!",
        status: "success",
        duration: 2000,
        isClosable: true,
        position: "bottom",
      });
      
    } catch (error) {
      toast({
        title: "Error Occured!",
        description: "Failed to update disappear status",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom",
      });
    }

    

    


  }

  function downloadTxtFile(data) {
    // Create a Blob with the data and set its type to plain text
    const blob = new Blob([data], { type: "text/plain" });

    // Create a link element
    const link = document.createElement("a");

    // Set the link's download attribute and href to the Blob URL
    link.download = "exportedChat";
    link.href = window.URL.createObjectURL(blob);

    // Append the link to the document
    document.body.appendChild(link);

    // Trigger a click on the link to start the download
    link.click();

    // Remove the link from the document
    document.body.removeChild(link);
  }

  const downloadChat = async () => {
    if (!selectedChat) return;

    try {
      const config = {
        headers: {
          Authorization: `Bearer ${user.token}`,
        },
      };

      const res = await axios.get(
        `/api/message/${selectedChat._id}`,
        config
      );
      const rawdata = res.data;
      console.log(rawdata);

      const data = rawdata.map((d)=>(d.content));
      console.log(data);

      downloadTxtFile(data);
    } catch (error) {
      toast({
        title: "Error Occured!",
        description: "Failed to Load the Messages",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom",
      });
    }
  };

  return (
    <>
      {selectedChat ? (
        <>
          <Text
            fontSize={{ base: "28px", md: "30px" }}
            pb={3}
            px={2}
            w="100%"
            fontFamily="Work sans"
            display="flex"
            justifyContent={{ base: "space-between" }}
            alignItems="center"
          >
            <IconButton
              display={{ base: "flex", md: "none" }}
              icon={<ArrowBackIcon />}
              onClick={() => setSelectedChat("")}
            />
            {!selectedChat.isGroupChat ? (
              <>
                <Box display="flex" flexDirection="column">
                  <div style={{ color: light ? darkColor : lightColor }}>
                    {getSender(user, selectedChat.users)}
                  </div>
                  <div
                    style={{
                      fontSize: "18px",
                      color: light ? darkColor : lightColor,
                    }}
                  >
                    {console.log(isOnline)}
                    {isOnline ? "Online" : "last Seen at: " + receiverLastSeen}
                  </div>
                  {console.log(
                    selectedChat?.users?.find((u) => u._id !== user._id)._id
                  )}
                </Box>
                <Box display="flex" flexDirection="row">
                  <VideoCallButton />
                  <ProfileModal
                    user={getSenderFull(user, selectedChat.users)}
                  />
                  <IconButton
                    icon={
                      <DownloadIcon color={light ? darkColor : lightColor} />
                    }
                    onClick={downloadChat}
                    _hover={light ? { bg: "#ebfaf8" } : { bg: "#616163" }} //blahblah
                    bg={light ? lightColor : "#2d2d2e"}
                    mr={2}
                  />
                  <Menu>
                    <MenuButton
                      _hover={light ? { bg: "#ebfaf8" } : { bg: "#616163" }} //blahblah
                      bg={light ? lightColor : "#2d2d2e"}
                      width={10}
                      height={10}
                      borderRadius={5}
                    >
                      <TimeIcon
                        color={light ? darkColor : lightColor}
                        width={4}
                        height={4}
                        mt={1}
                        mb={1}
                        mr={3}
                        ml={3}
                      />
                    </MenuButton>
                    <MenuList fontSize={16} fontFamily={"body"}>
                      <MenuItem
                        onClick={() => {
                          if (disappear != 0) {
                            setDisappear(0);
                            updateDisappearStatus("0");
                          }
                        }}
                        icon={disappear == 0 ? <CheckIcon /> : <></>}
                      >
                        Disabled
                      </MenuItem>
                      <MenuItem
                        onClick={() => {
                          if (disappear != 1) {
                            setDisappear(1);
                            updateDisappearStatus("1");
                          }
                        }}
                        icon={disappear == 1 ? <CheckIcon /> : <></>}
                      >
                        1 Minute
                      </MenuItem>
                      <MenuItem
                        onClick={() => {
                          if (disappear != 2) {
                            setDisappear(2);
                            updateDisappearStatus("2");
                          }
                        }}
                        icon={disappear == 2 ? <CheckIcon /> : <></>}
                      >
                        1 day
                      </MenuItem>
                    </MenuList>
                  </Menu>
                </Box>
              </>
            ) : (
              <>
                <Text color={light ? darkColor : lightColor}>
                  {selectedChat.chatName.toUpperCase()}
                </Text>

                <UpdateGroupChatModal
                  fetchAgain={fetchAgain}
                  setFetchAgain={setFetchAgain}
                  fetchMessages={fetchMessages}
                />
              </>
            )}
          </Text>
          <Box
            display="flex"
            flexDir="column"
            justifyContent="flex-end"
            p={3}
            bg={light ? "#E8E8E8" : "#525252"}
            w="100%"
            h="100%"
            borderRadius="lg"
            overflowY="hidden"
          >
            {loading ? (
              <Spinner
                size="xl"
                w={20}
                h={20}
                alignSelf="center"
                margin="auto"
              />
            ) : (
              <div className="messages">
                <ScrollableChat messages={messages} />
              </div>
            )}
            <FormControl
              onKeyDown={sendMessage}
              id="first-name"
              isRequired
              mt={3}
              display="flex"
              justifyContent="space-between"
            >
              {istyping ? (
                <div>
                  <Lottie
                    options={defaultOptions}
                    // height={50}
                    width={70}
                    style={{ marginBottom: 15, marginLeft: 0 }}
                  />
                </div>
              ) : (
                <></>
              )}
              <IconButton
                onClick={handleClick}
                icon={<AttachmentIcon />}
              ></IconButton>
              <input
                ref={hiddenFileInput}
                type="file"
                accept="*/*"
                style={{ display: "none" }}
                onChange={(e) => updateFile(e.target.files[0])}
              />
              <Input
                variant="filled"
                bg="#E0E0E0"
                placeholder="Enter a message.."
                value={newMessage}
                color={light ? darkColor : lightColor}
                onChange={typingHandler}
              />
            </FormControl>
          </Box>
        </>
      ) : (
        <Box
          display="flex"
          alignItems="center"
          justifyContent="center"
          h="100%"
          bg={light ? lightColor : darkColor}
        >
          <Text
            fontSize="3xl"
            pb={3}
            fontFamily="Work sans"
            color={light ? darkColor : lightColor}
          >
            Click on a user to start chatting
          </Text>
        </Box>
      )}
      <Modal isOpen={isOpen} onClose={onClose} size="sm">
        <ModalOverlay />
        <ModalContent>
          <ModalBody>
            <Box
              display="flex"
              justifyContent="space-between"
              alignItems="center"
              width="100%"
            >
              <Box> Video Call From : {caller}</Box>
              <Button
                colorScheme="green"
                onClick={() => {
                  history.push("/video");
                }}
                mr={2}
              >
                Pick Up
              </Button>
              <Button colorScheme="red" onClick={onClose}>
                Ignore
              </Button>
            </Box>
          </ModalBody>
        </ModalContent>
      </Modal>
    </>
  );
};

export default SingleChat;
