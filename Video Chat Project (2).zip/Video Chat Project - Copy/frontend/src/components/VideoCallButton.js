// VideoCallButton.js

import { Button, IconButton } from "@chakra-ui/react";
import { ChatState } from "../Context/ChatProvider";
import React from "react";
import { useHistory } from "react-router-dom";
import { FaVideo } from "react-icons/fa";

const VideoCallButton = () => {
  const { selectedChat, user, socketState,light,lightColor,darkColor } = ChatState();
  const history = useHistory();

  const handleVideoCall = () => {
    if (selectedChat && selectedChat.users.length === 2) {
      const receiverId = selectedChat.users.find((u) => u._id !== user._id)._id;
      socketState.emit("video call invitation", 
        user._id,
        receiverId,
      );
      history.push("/video");
    }
  };

  return (
    <IconButton
      onClick={handleVideoCall}
      _hover={light ? { bg: "#ebfaf8" } : { bg: "#616163" }} //blahblah
      bg={light ? lightColor : "#2d2d2e"}
      marginRight={4}
      icon={<FaVideo color={light?darkColor:lightColor}/>}
    ></IconButton>
  );
};

export default VideoCallButton;
