import { Avatar, Tooltip } from "@chakra-ui/react";
import React from "react";
import ScrollableFeed from "react-scrollable-feed";
import { ChatState } from "../Context/ChatProvider";
import {
  isLastMessage,
  isSameSender,
  isSameSenderMargin,
  isSameUser,
} from "../config/ChatLogics";

const ScrollableChat = ({ messages }) => {
  const { user } = ChatState();

  const handleDownload = (url, fileName) => {
    const link = document.createElement("a");
    link.href = url;
    console.log(url);
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <ScrollableFeed>
      {messages &&
        messages.map((m, i) => {
          // Check if the message should be displayed
          console.log(`isDis: ${m.isDis}`)
          var nowTime =Date.now();
          var Distime = Date.parse(m.disTime);
          const shouldDisplay =
            m.isDis === undefined || m.isDis ===false || // Check if 'isDis' is undefined
            (m.isDis !== false && // Check if 'isDis' is not false
              (!m.disTime || Distime > nowTime)); // Check if 'disTime' is greater than the current time

              console.log(`should display: ${shouldDisplay}`)
              console.log(`dis time is: ${Distime}`);
              console.log(`now time is: ${nowTime}`);

          // Render the message only if it meets the criteria
          return shouldDisplay ? (
            <div style={{ display: "flex" }} key={m._id}>
              {(isSameSender(messages, m, i, user._id) ||
                isLastMessage(messages, i, user._id)) && (
                <Tooltip
                  label={m.sender.name}
                  placement="bottom-start"
                  hasArrow
                >
                  <Avatar
                    mt="7px"
                    mr={1}
                    size="sm"
                    cursor="pointer"
                    name={m.sender.name}
                    src={m.sender.pic}
                  />
                </Tooltip>
              )}
              <span
                style={{
                  backgroundColor: `${
                    m.sender._id === user._id ? "#BEE3F8" : "#B9F5D0"
                  }`,
                  marginLeft: isSameSenderMargin(messages, m, i, user._id),
                  marginTop: isSameUser(messages, m, i, user._id) ? 3 : 10,
                  borderRadius: "20px",
                  padding: "5px 15px",
                  maxWidth: "75%",
                }}
              >
                {m.url === "" ? (
                  m.content
                ) : (
                  <a
                    href="#"
                    onClick={() => handleDownload(m.url, m.content)}
                    style={{ fontWeight: "bold", textDecoration: "underline" }}
                  >
                    {m.content}
                  </a>
                )}
              </span>
            </div>
          ) : null; // Return null for messages that should not be displayed
        })}
    </ScrollableFeed>
  );
};

export default ScrollableChat;
