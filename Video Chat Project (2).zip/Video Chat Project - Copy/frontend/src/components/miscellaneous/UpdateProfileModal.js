import { ViewIcon } from "@chakra-ui/icons";
import {
  Button,
  IconButton,
  Image,
  Input,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Text,
  useDisclosure,
  useToast,
} from "@chakra-ui/react";
import axios from "axios";
import React, { useState } from "react";
import { ChatState } from "../../Context/ChatProvider";

const UpdateProfileModal = ({ children }) => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const toast = useToast();
  const {user, setUser,userName,setUserName,userPic,setUserPic} = ChatState();
  const [editedName, setEditedName] = useState(userName);
  const [selectedImage, setSelectedImage] = useState(null);
  const [tempImage,setTempImage] = useState();

  const handleImageChange = (e) => {
    const file = e.target.files[0];

    // Display the selected image immediately
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setTempImage(reader.result); // Assuming setUserPic is a state updater for the user's profile picture
      };
      reader.readAsDataURL(file);
    }
  };



  const updatePassword = async (currentPassword, newPassword) => {
    try {
      const config = {
        headers: {
          Authorization: `Bearer ${user.token}`,
          "Content-Type": "application/json",
        },
      };

      const data = { currentPassword, newPassword };

      const response = await axios.put(
        "/api/user/updatepassword",
        data,
        config
      );
      console.log(response.data); // Password updated successfully
    } catch (error) {
      console.error("Password update failed:", error.response.data.message);
    }
  };

  const updateImage =  (pic) => {
    const data = new FormData();
    data.append("file", pic);
    data.append("upload_preset", "video-chat-app");
    data.append("cloud_name", "dz7ln36yd");
    fetch("https://api.cloudinary.com/v1_1/dz7ln36yd/image/upload", {
      method: "post",
      body: data,
    })
      .then((res) => res.json())
      .then((data) => {
        console.log(data);
        setSelectedImage(data.url.toString());
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const hiddenFileInput = React.useRef(null);

  const handleClick = () => {
    hiddenFileInput.current.click();
  };

  const handleSave = async () => {
    // Perform save action here, e.g., update the user's name and passwords
    // You can call an API to update this information
    console.log("Name:", editedName);
    console.log("Current Password:", currentPassword);
    console.log("New Password:", newPassword);
    console.log("Confirm Password:", confirmPassword);

    if (editedName === "") {
      toast({
        title: "Error Occured!",
        description: "Username cannot be blank",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom",
      });
      return;
    }

    try {
      // Update username
      if (editedName !== userName) {
        const config = {
          headers: {
            Authorization: `Bearer ${user.token}`,
            "Content-Type": "application/json",
          },
        };
        const data = { editedName };
        const response = await axios.put(
          "/api/user/updateusername",
          data,
          config
        );
        console.log(response.data); // username updated successfully
        setUserName(editedName);
        toast({
          title: "Updated UserName Successfully!",
          status: "success",
          duration: 5000,
          isClosable: true,
          position: "bottom",
        });
      }

      //upload image
      if (selectedImage) {
        try {
          const config = {
          headers: {
            Authorization: `Bearer ${user.token}`,
            "Content-Type": "application/json",
          },
        };
        const data = { selectedImage };
        const response = await axios.put(
          "/api/user/userpic",
          data,
          config
        );
        console.log(response);
        setUserPic(selectedImage);
        toast({
          title: "Updated Picture Successfully!",
          status: "success",
          duration: 5000,
          isClosable: true,
          position: "bottom",
        });
      
          
          
        } catch (error) {
          console.log(error);
          toast({
            title: "Couldnt update picture",
            status: "error",
            duration: 5000,
            isClosable: true,
            position: "bottom",
          });
          
        }
      }
        

      // Update password
      if (newPassword && confirmPassword && currentPassword) {
        if (newPassword === confirmPassword) {
          await updatePassword(currentPassword, newPassword);
          toast({
            title: "Updated Password Successfully!",
            status: "success",
            duration: 5000,
            isClosable: true,
            position: "bottom",
          });
        } else {
          toast({
            title: "Error Occured!",
            description: "Passwords don't match",
            status: "error",
            duration: 5000,
            isClosable: true,
            position: "bottom",
          });
          return;
        }
      } else if (!newPassword && !confirmPassword && !currentPassword) {
        console.log("no update to password has been made");
      } else {
        toast({
          title: "Error Occured!",
          description: "Password fields partially filled",
          status: "error",
          duration: 5000,
          isClosable: true,
          position: "bottom",
        });
        return;
      }
    } catch (error) {
      console.error(
        "Update failed:",
        error.response?.data?.message || error.message
      );
      toast({
        title: "Error Occured!",
        description: "Update failed",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "bottom",
      });
      return;
    }

    // try {

    //     const config = {
    //       headers: {
    //         Authorization: `Bearer ${user.token}`,
    //         "Content-Type": "application/json",
    //       },
    //     };
    //     const {response} = await axios.get(
    //       "/api/user/userinfo",
    //       config
    //     );
    //     console.log(response);
    //     // localStorage.setItem("userInfo", JSON.stringify(response));
    //     setUser(response);
        
    // } catch (error) {
    //     console.error(
    //       "user updation failed:",
    //       error.response?.data?.message || error.message
    //     );
    //     return;
        
    // }

    // Close the modal after saving
    onClose();
  };

  return (
    <>
      {children ? (
        <span onClick={onOpen}>{children}</span>
      ) : (
        <IconButton
          display={{ base: "flex" }}
          icon={<ViewIcon />}
          onClick={onOpen}
        ></IconButton>
      )}

      <Modal size="lg" isOpen={isOpen} onClose={onClose} isCentered>
        <ModalOverlay />
        <ModalContent h="600px">
          <ModalHeader
            fontSize="40"
            fontFamily="work sans"
            display="flex"
            justifyContent="center"
          >
            <Input
              value={editedName}
              onChange={(e) => setEditedName(e.target.value)}
              variant="flushed"
              size="md"
              autoFocus
            />
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody
            display="flex"
            flexDir="column"
            alignItems="center"
            justifyContent="space-between"
          >
            <Image
              borderRadius="full"
              boxSize="150px"
              src={selectedImage || userPic}
              alt={userName}
            />

            {/* Add the Update Image Button here */}
            <input
              ref={hiddenFileInput}
              type="file"
              accept="image/*"
              style={{ display: "none" }}
              onChange={(e) => updateImage(e.target.files[0])}
            />
            <Button colorScheme="blue" mt={2} size="sm" onClick={handleClick}>
              Update Image
            </Button>
            <Text
              fontSize={{ base: "28px", md: "30px" }}
              fontFamily="Work sans"
            >
              Email: {user.email}
            </Text>
            <Input
              placeholder="Current Password"
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              variant="flushed"
              size="md"
              mb={2}
            />
            <Input
              placeholder="New Password"
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              variant="flushed"
              size="md"
              mb={2}
            />
            <Input
              placeholder="Confirm Password"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              variant="flushed"
              size="md"
            />
          </ModalBody>

          <ModalFooter>
            <Button colorScheme="blue" mr={3} onClick={handleSave}>
              Save
            </Button>
            <Button onClick={onClose}>Cancel</Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
};

export default UpdateProfileModal;
