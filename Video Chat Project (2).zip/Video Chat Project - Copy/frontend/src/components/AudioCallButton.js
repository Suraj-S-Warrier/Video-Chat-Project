import { Button } from '@chakra-ui/react'
import React from 'react'

const AudioCallButton = () => {
  return (
    <Button>
      Phone
    </Button>
  )
}

export default AudioCallButton
