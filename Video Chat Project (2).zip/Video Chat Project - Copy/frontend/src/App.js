import { Route } from "react-router-dom"
import "./App.css";
import HomePage from "./Pages/HomePage";
import ChatPage from "./Pages/ChatPage";
import VideoPage from "./Pages/VideoPage";
// import Basics from "./Pages/VideoPageReadyMade";
import dummyFile from "./Pages/dummyFile";
// import AgoraRTC from "agora-rtc-sdk-ng";
// import { AgoraRTCProvider } from "agora-rtc-react";
// const client = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });
function App() {

  return (
    <div className="App">
      <Route exact path="/" component={HomePage} />
      <Route path="/chats" component={ChatPage} />
      {/* <AgoraRTCProvider client={client}> */}
        <Route path="/video" component={VideoPage} />
      {/* </AgoraRTCProvider> */}
    </div>
  );
}

export default App;
