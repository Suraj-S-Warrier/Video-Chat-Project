import { createContext, useContext, useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
//import {  useNavigate } from "react-router-dom";
import io from "socket.io-client";


const ChatContext = createContext();
const ChatProvider = ({ children }) => {
  const [user, setUser] = useState();
  const [selectedChat, setSelectedChat] = useState();
  const [chats, setChats] = useState([]);
  const [notification,setNotification] = useState([]);
  const [socketState,setSocketState] = useState();
  const [userName,setUserName] =  useState();
  const [userPic,setUserPic] = useState();
  const [light,setLight]=  useState(true);
  const [lightColor,setLightColor] = useState("white")
  const [darkColor,setDarkColor] = useState("black")


  //const navigate = useNavigate();
  const history = useHistory();

  

  useEffect(() => {
    const userinfo = JSON.parse(localStorage.getItem("userInfo"));
    setUser(userinfo);
    // socket = io(ENDPOINT);
    // setSocketState(socket);
    // socket.emit("setup", user);
    // socket.on("connected", () => setSocketConnected(true));

    setUserName(userinfo?.name);
    setUserPic(userinfo?.pic);
    

    if (!userinfo) {
      //navigate("/");
      history.push("/");
    }
  }, [history]);

  return (
    <ChatContext.Provider
      value={{
        user,
        setUser,
        selectedChat,
        setSelectedChat,
        chats,
        setChats,
        notification,
        setNotification,
        socketState,setSocketState,
        userName,setUserName,
        userPic,setUserPic,
        light, setLight,
        lightColor,setLightColor,
        darkColor, setDarkColor
        
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const ChatState = () => {
  return useContext(ChatContext);
};

export default ChatProvider;
